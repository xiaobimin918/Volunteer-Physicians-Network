# 小火箭Shadowrocket在线安装

【1】[2020苹果美国 韩国 日本 香港 台湾 英国等地区Apple ID账号免费分享](https://github.com/openwrt-ssr/appleid/wiki/2020%E8%8B%B9%E6%9E%9C%E7%BE%8E%E5%9B%BD-%E9%9F%A9%E5%9B%BD-%E6%97%A5%E6%9C%AC-%E9%A6%99%E6%B8%AF-%E5%8F%B0%E6%B9%BE-%E8%8B%B1%E5%9B%BD%E7%AD%89%E5%9C%B0%E5%8C%BAApple-ID%E8%B4%A6%E5%8F%B7%E5%85%8D%E8%B4%B9%E5%88%86%E4%BA%AB)
